package com.example.DMS.repositiry;

import org.springframework.data.repository.CrudRepository;

import com.example.DMS.Models.Trainer;

public interface TrainerRepository extends CrudRepository<Trainer, Integer> {

}
